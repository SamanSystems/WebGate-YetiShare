<?php
// Masoud Amini
// masoudamini.ir
require_once('../../../includes/master.inc.php');

// load plugin details
$pluginConfig   = pluginHelper::pluginSpecificConfiguration('zarinpal');
$pluginSettings = $pluginConfig['data']['plugin_settings'];
$zarinpal_Merchantid    = '';
if (strlen($pluginSettings))
{
    $pluginSettingsArr = json_decode($pluginSettings, true);
    $zarinpal_Merchantid       = $pluginSettingsArr['zarinpal_email'];
}

if (!isset($_REQUEST['days']))
{
    redirect(WEB_ROOT . '/index.html');
}

// require login
if (!isset($_REQUEST['i']))
{
    $Auth->requireUser('login.php');
    $userId    = $Auth->id;
    $username  = $Auth->username;
    $userEmail = $Auth->email;
}
else
{
    $user = UserPeer::loadUserByIdentifier($_REQUEST['i']);
    if (!$user)
    {
        die('User not found!');
    }

    $userId    = $user->id;
    $username  = $user->username;
    $userEmail = $user->email;
}

$days = (int) (trim($_REQUEST['days']));

$fileId = null;
if (isset($_REQUEST['f']))
{
    $file = file::loadByShortUrl($_REQUEST['f']);
    if ($file)
    {
        $fileId = $file->id;
    }
}

// create order entry
$orderHash = MD5(time() . $userId);
$amount    = number_format(constant('SITE_CONFIG_COST_FOR_' . $days . '_DAYS_PREMIUM'), 2);
$order     = OrderPeer::create($userId, $orderHash, $days, $amount, $fileId);
if ($order)
{    
	$MerchantID = $_REQUEST['MID'];
	$Description = $days . ' days extension for ' . $username;;  // Required
	$Email = $userEmail; // Optional
	$Mobile =''; // Optional
	$CallbackURL = WEB_ROOT . '/zarinpal.php?custom=' . $orderHash;


	// URL also Can be https://ir.zarinpal.com/pg/services/WebGate/wsdl
	$client = new SoapClient('https://de.zarinpal.com/pg/services/WebGate/wsdl', array('encoding' => 'UTF-8')); 

	$result = $client->PaymentRequest(
						array(
								'MerchantID' 	=> $MerchantID,
								'Amount' 	=> $amount,
								'Description' 	=> $Description,
								'Email' 	=> $Email,
								'Mobile' 	=> $Mobile,
								'CallbackURL' 	=> $CallbackURL
							)
	);

	//Redirect to URL You can do it also by creating a form
	if($result->Status == 100)
	{
		$_SESSION['Authority']=$result->Authority;
		Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);
	} else {
		echo'ERR: '.$result->Status;
	}
	

    
}