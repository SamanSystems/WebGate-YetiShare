<?
// Masoud Amini
// masoudamini.ir
//error_reporting(E_ALL);
//ini_set('display_errors', 1);


echo'here';
// global includes
require_once('../../../includes/master.inc.php');

// validate IPN with zarinpal

	//$MerchantID = 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX';
	//$Amount = 1000; //Amount will be based on Toman
	$Authority = $_GET['Authority'];
	$pluginConfig   = pluginHelper::pluginSpecificConfiguration('zarinpal');
	$pluginSettings = $pluginConfig['data']['plugin_settings'];
	$zarinpal_Merchantid    = '';
	if (strlen($pluginSettings))
	{
		$pluginSettingsArr = json_decode($pluginSettings, true);
		$zarinpal_Merchantid       = $pluginSettingsArr['zarinpal_email'];
	}

// make sure payment has completed and it's for the correct zarinpal account
	if($_GET['Status'] == 'OK'){
		// URL also Can be https://ir.zarinpal.com/pg/services/WebGate/wsdl
		$client = new SoapClient('https://de.zarinpal.com/pg/services/WebGate/wsdl', array('encoding' => 'UTF-8')); 
		$paymentTracker = $_REQUEST['custom'];
		$order          = OrderPeer::loadByPaymentTracker($paymentTracker);
		$result = $client->PaymentVerification(
						  	array(
									'MerchantID'	 => $MerchantID,
									'Authority' 	 => $Authority,
									'Amount'	 => $order->amount
								)
		);

		if($result->Status == 100){
			echo 'Transation success. RefID:'. $result->RefID;
			
			// load order using custom payment tracker hash
    
    if ($order)
    {
        $extendedDays  = $order->days;
        $userId        = $order->user_id;
        $upgradeUserId = $order->upgrade_user_id;
        $orderId       = $order->id;

        // log in payment_log
        $zarinpal_vars = "";
        foreach ($_REQUEST AS $k => $v)
        {
            $zarinpal_vars .= $k . " => " . $v . "\n";
        }
        $dbInsert                = new DBObject("payment_log", array("user_id", "date_created", "amount",
            "currency_code", "from_email", "to_email", "description",
            "request_log")
        );
        $dbInsert->user_id       = $userId;
        $dbInsert->date_created  = date("Y-m-d H:i:s", time());
        $dbInsert->amount        = $_REQUEST['mc_gross'];
        $dbInsert->currency_code = $_REQUEST['mc_currency'];
        $dbInsert->from_email    = $_REQUEST['payer_email'];
        $dbInsert->to_email      = $_REQUEST['business'];
        $dbInsert->description   = $extendedDays . ' days extension';
        $dbInsert->request_log   = $zarinpal_vars;
        $dbInsert->insert();

        // make sure the amount paid matched what we expect
        if ($_REQUEST['mc_gross'] != $order->amount)
        {
            // order amounts did not match
            die();
        }

        // make sure the order is pending
        if ($order->order_status == 'completed')
        {
            // order has already been completed
            die();
        }

        // update order status to paid
        $dbUpdate               = new DBObject("premium_order", array("order_status"), 'id');
        $dbUpdate->order_status = 'completed';
        $dbUpdate->id           = $orderId;
        $effectedRows           = $dbUpdate->update();
        if ($effectedRows === false)
        {
            // failed to update order
            die();
        }

        // extend/upgrade user
        $user          = UserPeer::loadUserById($userId);
        $newExpiryDate = strtotime('+' . $order->days . ' days');
        if (($user->level == 'paid user') || ($user->level == 'admin'))
        {
            // add onto existing period
            $existingExpiryDate = strtotime($user->paidExpiryDate);

            // if less than today just revert to now
            if ($existingExpiryDate < time())
            {
                $existingExpiryDate = time();
            }

            $newExpiryDate = (int) $existingExpiryDate + (int) ($order->days * (60 * 60 * 24));
        }

        $newUserType = 'paid user';
        if ($user->level == 'admin')
        {
            $newUserType = 'admin';
        }

        // update user account to premium
        $dbUpdate                 = new DBObject("users", array("level", "lastPayment", "paidExpiryDate"), 'id');
        $dbUpdate->level          = $newUserType;
        $dbUpdate->lastPayment    = date("Y-m-d H:i:s", time());
        $dbUpdate->paidExpiryDate = date("Y-m-d H:i:s", $newExpiryDate);
        $dbUpdate->id             = $userId;
        $effectedRows             = $dbUpdate->update();
        if ($effectedRows === false)
        {
            // failed to update user
            die();
        }

        // append any plugin includes
        pluginHelper::includeAppends('payment_ipn_zarinpal.php');
    }
		} else {
			echo 'Transation failed. Status:'. $result->Status;
		}

	} else {
		echo 'Transaction canceled by user';
	}
