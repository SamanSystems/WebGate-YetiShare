<?php
// Masoud Amini
// masoudamini.ir
// core plugin config
$pluginConfig = array();
$pluginConfig['plugin_name']             = 'zarinpal Payment Integration';
$pluginConfig['folder_name']             = 'zarinpal';
$pluginConfig['plugin_description']      = 'Accept payments using zarinpal.';
$pluginConfig['plugin_version']          = 1;
$pluginConfig['required_script_version'] = 3.2;
